import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Main31 {
    String gotoPage = "";

    public static void main(String[] args) {
        new Main31().querybalance();
        String s = new Main31().chargePayfeeNew();
        new Main31().gotoPayPage(s.split("!")[0]);
        String s1 = new Main31().wkMobWapBankPay(s.split("!")[1]);

        s1 = new Main31().directPay(s1);
        System.out.println(s1);
        s1 = new Main31().checkmweb(s1);

    }


    public void querybalance() {
        try {
            String mobile = "13099928388";
            Map<String, String> header = new HashMap<>();

            header.put("content-type", "application/x-www-form-urlencoded");


            Connection.Response execute = Jsoup.connect("https://kapi.10010.com/KCard/payfee/querybalance")
                    .referrer("https://txwk.10010.com/KCard/mPages/addCredit.htm")
                    .userAgent("Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1")
                    .requestBody("phone=" + mobile)
                    .ignoreContentType(true)
                    .ignoreHttpErrors(true)
                    .headers(header)
                    .method(Connection.Method.POST)
                    .execute();


            String body = execute.body();
            System.out.println(body);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String chargePayfeeNew() {
        try {
            Map<String, String> header = new HashMap<>();

            header.put("content-type", "application/x-www-form-urlencoded");

            String mobile = "1309992838";
            String payAmount = "3000";


            Connection.Response execute = Jsoup.connect("https://txwk.10010.com/KCard/payfee/chargePayfeeNew")
                    .referrer("https://txwk.10010.com/KCard/mPages/addCredit.htm")
                    .userAgent("Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1")
                    .requestBody("mobile=" + mobile + "&payAmount=" + payAmount + "&actionID=WX_KCARD_PAYPHONE_REDIRECT&scene=actionID%3DWX_KCARD_PAYPHONE_REDIRECTFromchargePayfeeNew")
                    .ignoreContentType(true)
                    .ignoreHttpErrors(true)
                    .headers(header)
                    .method(Connection.Method.POST)
                    .execute();


            String body = execute.body();
            System.out.println(body);
            JSONObject jsonObject = JSON.parseObject(body);
            String respCode = jsonObject.getString("respCode");

            JSONObject data = jsonObject.getJSONObject("data");

            String reqKey = data.getString("reqKey");
            String gotoPayPage = data.getString("gotoPayPage");

            this.gotoPage = gotoPayPage;
            return gotoPayPage + "!" + reqKey;

        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }


    public void gotoPayPage(String s) {
        try {
            Map<String, String> header = new HashMap<>();

            header.put("content-type", "application/x-www-form-urlencoded");


            Connection.Response execute = Jsoup.connect(s)
                    .referrer("https://txwk.10010.com/KCard/mPages/addCredit.htm")
                    .userAgent("Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1")

                    .ignoreContentType(true)
                    .ignoreHttpErrors(true)
                    .headers(header)
                    .method(Connection.Method.GET)
                    .execute();


            Document parse = execute.parse();

//            System.out.println(body);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private String wkMobWapBankPay(String key) {
        try {
            Map<String, String> header = new HashMap<>();

            header.put("content-type", "application/x-www-form-urlencoded");


            Connection.Response execute = Jsoup.connect("https://upay.10010.com/npfwap/NpfMob/wkMobWapBankPay/wkMobWapBankPay")
                    .referrer("https://txwk.10010.com/")
                    .userAgent("Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1")

                    .ignoreContentType(true)
                    .ignoreHttpErrors(true)
                    .followRedirects(false)
                    .headers(header)
                    .requestBody("reqKey=" + key + "&&channelKey=353")
                    .method(Connection.Method.POST)
                    .execute();


            String Location = execute.header("Location");


            return Location;


        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    private String directPay(String url) {

        try {
            Map<String, String> header = new HashMap<>();

            header.put("content-type", "application/x-www-form-urlencoded");


            Connection.Response execute = Jsoup.connect(url)
                    .referrer("https://txwk.10010.com/")
                    .userAgent("Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1")

                    .ignoreContentType(true)
                    .ignoreHttpErrors(true)
                    .followRedirects(false)
                    .headers(header)
                    .method(Connection.Method.GET)
                    .execute();


            String Location = execute.header("Location");

            System.out.println(Location);
            return Location;


        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String checkmweb(String url) {

        try {
            Map<String, String> header = new HashMap<>();

            header.put("content-type", "application/x-www-form-urlencoded");


            Connection.Response execute = Jsoup.connect(url)
                    .referrer("https://txwk.10010.com/")
                    .userAgent("Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1")

                    .ignoreContentType(true)
                    .ignoreHttpErrors(true)
                    .followRedirects(false)
                    .headers(header)
                    .method(Connection.Method.GET)
                    .execute();


            String parse = execute.body();


            String s = StringUtils.substringBetween(parse, "url=\"", "\";");

            System.out.println(s);
            return s;


        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
